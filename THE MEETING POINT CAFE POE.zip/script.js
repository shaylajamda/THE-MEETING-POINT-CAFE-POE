// THE MEETING POINT CAFE - JAVASCRIPT


// 1. MOBILE NAVIGATION MENU

// Find the menu button and navigation links
const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

// Check if the menu button exists
if (menuButton && navLinks) {

    // Wait for someone to click the menu button
    menuButton.addEventListener("click", function() {

        // Show or hide the navigation links
        navLinks.classList.toggle("show");

    });

}


// 2. CONTACT FORM AND CLIENT-SIDE VALIDATION

// Find the contact form
const contactForm = document.querySelector("#contact-form");

// Find the thank-you message area
const thankYouMessage = document.querySelector("#thank-you-message");

// Find the error message area
const formErrors = document.querySelector("#form-errors");


// Check whether the contact form exists
if (contactForm && thankYouMessage && formErrors) {

    // Wait for the visitor to submit the form
    contactForm.addEventListener("submit", function(event) {

        // Stop the page from refreshing
        event.preventDefault();


        // Get the information entered by the visitor
        const name = document.querySelector("#contact-name").value.trim();

        const email = document.querySelector("#contact-email").value.trim();

        const phoneNumber = document.querySelector("#contact-number").value.trim();

        const requestType = document.querySelector("#request-type").value;

        const message = document.querySelector("#contact-message").value.trim();

        const date = document.querySelector("#reservation-date").value;

        const time = document.querySelector("#reservation-time").value;


        // Create an empty list for errors
        const errors = [];


        // NAME VALIDATION
        if (name === "") {

            errors.push("Please enter your name.");

        }


        // EMAIL VALIDATION
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {

            errors.push("Please enter a valid email address.");

        }


        // SOUTH AFRICAN PHONE NUMBER VALIDATION

        // Removes spaces and hyphens
        const cleanedPhoneNumber = phoneNumber.replace(/[\s-]/g, "");

        // Accepts examples such as:
        // 0821234567
        // +27821234567
        const phonePattern = /^(?:\+27|0)[6-8][0-9]{8}$/;

        if (!phonePattern.test(cleanedPhoneNumber)) {

            errors.push(
                "Please enter a valid South African phone number. Example: 0821234567."
            );

        }


        // REQUEST TYPE VALIDATION
        if (requestType === "") {

            errors.push("Please select the type of request.");

        }


        // MESSAGE VALIDATION
        if (message === "") {

            errors.push("Please enter a message.");

        }


        // If there are errors
        if (errors.length > 0) {

            // Clear old errors
            formErrors.innerHTML = "";

            // Create an error heading
            const errorHeading = document.createElement("strong");

            errorHeading.textContent =
                "Please correct the following information:";

            formErrors.appendChild(errorHeading);


            // Create a list of errors
            const errorList = document.createElement("ul");


            // Add every error to the list
            errors.forEach(function(error) {

                const listItem = document.createElement("li");

                listItem.textContent = error;

                errorList.appendChild(listItem);

            });


            // Add the list to the error area
            formErrors.appendChild(errorList);


            // Show the error messages
            formErrors.hidden = false;


            // Hide the thank-you message
            thankYouMessage.hidden = true;


            // Stop the form here
            return;

        }


        // Hide errors because the form is valid
        formErrors.hidden = true;


        // Clear previous thank-you message
        thankYouMessage.innerHTML = "";


        // Create thank-you heading
        const heading = document.createElement("h3");

        heading.textContent = "Thank you, " + name + "!";


        // Create thank-you paragraph
        const paragraph = document.createElement("p");


        // Show a different response depending on request type
        if (requestType === "Reservation") {

            paragraph.textContent =
                "Thank you for your reservation request. We will get back to you to confirm your reservation.";

        }

        else if (requestType === "Feedback") {

            paragraph.textContent =
                "Thank you for your feedback! We appreciate you taking the time to share your thoughts with us.";

        }

        else if (requestType === "General enquiry") {

            paragraph.textContent =
                "Thank you for your enquiry. We will get back to you as soon as possible.";

        }

        else if (requestType === "Appointment") {

            paragraph.textContent =
                "Thank you for your appointment request. We will get back to you to discuss the details.";

        }


        // Add heading and message
        thankYouMessage.appendChild(heading);

        thankYouMessage.appendChild(paragraph);


        // Show reservation date and time if entered
        if (date || time) {

            const details = document.createElement("p");

            details.textContent =
                "Your preferred date and time: " +
                (date || "Not provided") +
                " at " +
                (time || "Not provided");

            thankYouMessage.appendChild(details);

        }


        // Show thank-you message
        thankYouMessage.hidden = false;


        // Scroll to the message
        thankYouMessage.scrollIntoView({
            behavior: "smooth"
        });


        // Clear the form
        contactForm.reset();

    });

}

// 3. GALLERY IMAGE ZOOM

// Find all images inside the gallery
const galleryImages = document.querySelectorAll(".gallery img");

// Go through each gallery image
galleryImages.forEach(function(image) {

    // Wait for the visitor to click the image
    image.addEventListener("click", function() {

        // Create a dark background
        const overlay = document.createElement("div");
        overlay.classList.add("image-overlay");

        // Create a larger image
        const largeImage = document.createElement("img");
        largeImage.src = image.src;
        largeImage.alt = image.alt;

        // Add the large image to the overlay
        overlay.appendChild(largeImage);

        // Add the overlay to the webpage
        document.body.appendChild(overlay);

        // Remove the overlay when the visitor clicks outside the image
        overlay.addEventListener("click", function() {
            overlay.remove();
        });

    });

});

// 4. WELCOME MESSAGE

// Find the welcome message and button
const welcomeMessage = document.querySelector("#welcome-message");
const closeWelcomeButton = document.querySelector("#close-welcome");

// Check if both elements exist
if (welcomeMessage && closeWelcomeButton) {

    // Display the welcome message
    welcomeMessage.hidden = false;

    // Wait for the visitor to click the button
    closeWelcomeButton.addEventListener("click", function() {

        // Hide the welcome message
        welcomeMessage.hidden = true;

    });

}